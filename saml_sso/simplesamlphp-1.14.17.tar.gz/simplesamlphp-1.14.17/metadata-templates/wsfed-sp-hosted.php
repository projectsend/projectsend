<?php
/**
 * WS-Federation SP configuration for SimpleSAMLphp.
 *
 * Required fields:
 *  - host
 */

$metadata['__DYNAMIC:1__'] = array(
	'host' => '__DEFAULT__',
);
