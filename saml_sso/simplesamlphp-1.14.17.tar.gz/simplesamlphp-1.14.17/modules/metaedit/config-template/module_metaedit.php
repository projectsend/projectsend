<?php
/* 
 * The configuration of simpleSAMLphp statistics package
 */

$config = array (
	'metahandlerConfig' => array('directory' => 'metadata/metaedit'),
	'auth' => 'saml2',
	'useridattr' => 'eduPersonPrincipalName',
);

